function [d] = load1 
d=900; end  % Set total load here
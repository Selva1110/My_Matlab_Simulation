function [d] = Bdat1 
d=[0.000125 0 ;        % Only transmission losses considered
    0 0.0000625;]; end % Constant and internal losses neglected
function [d] = data1
%  n a   b   c     min  max
d=[1 320 6.2 0.004 50   250 ;
   2 200 6.0 0.003 50   350 ;];
end
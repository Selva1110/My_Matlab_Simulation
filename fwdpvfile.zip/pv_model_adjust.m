% Matlab script for modeling a photovoltaic array
%
% Tested with MATLAB Version 7.3.0.267 (R2006b)
%
% Author: Marcelo Gradella Villalva
% Email: mvillalva@gmail.com
% University of Campinas, Brazil - May/2009 
% http://www.unicamp.br
%
% You may freely modify and distribute this file. 
% Please cite my work if you find it useful.
%
% For more information refer to:
%
% M. G. Villalva, J. R. Gazoli, E. Ruppert F.
% "Comprehensive approach to modeling and simulation of photovoltaic arrays"
% IEEE Transactions on Power Electronics, 2009
% vol. 25, no. 5, pp. 1198--1208, ISSN 0885-8993
% 
% M. G. Villalva, J. R. Gazoli, E. Ruppert F.
% "Modeling and circuit-based simulation of photovoltaica arrays"
% Brazilian Journal of Power Electronics, 2009
% vol. 14, no. 1, pp. 35--45, ISSN 1414-8862
%
% Visit: http://sites.google.com/site/mvillalva/pvmodel

clear all

clc

%% Information from the KC200GT solar array datasheet

%  You may change these parameters to fit the I-V model
%  to other kinds of solar arrays.

Iscn = 8.21;            %Nominal short-circuit voltage [A] 
Vocn = 32.9;            %Nominal array open-circuit voltage [V] 
Imp = 7.61;             %Array current @ maximum power point [A] 
Vmp = 26.3;             %Array voltage @ maximum power point [V] 
Pmax_e = Vmp*Imp;       %Array maximum output peak power [W] 
Kv = -0.123;            %Voltage/temperature coefficient [V/K] 
Ki = 3.18e-3;           %Current/temperature coefficient [A/K] 
Ns = 54;                %Nunber of series cells 

%% Array with Nss x Npp modules
Nss = 15;
Npp = 2;

%% Constants

k = 1.3806503e-23;   %Boltzmann [J/K]
q = 1.60217646e-19;  %Electron charge [C]
a = 1.3;             %Diode constant

%% Nominal values 

Gn = 1000;           % Nominal irradiance [W/m^2] @ 25oC
Tn = 25 + 273.15;    % Nominal operating temperature [K]


%% Adjusting algorithm

% The model is adjusted at the nominal condition
T = Tn;
G = Gn; 

Vtn = k * Tn / q;                     %Thermal junction voltage (nominal) 
Vt = k * T / q;                       %Thermal junction voltage (current temperature)

Ion = Iscn/(exp(Vocn/a/Ns/Vtn)-1);    % Nominal diode saturation current

Io = Ion;

% Reference values of Rs and Rp   
Rs_max = (Vocn - Vmp)/ Imp;
Rp_min = Vmp/(Iscn-Imp) - Rs_max;

% Initial guesses of Rp and Rs
Rp = Rp_min;
Rs = 0;

tol = 0.001; % Power mismatch Tolerance
 
P=[0];
 
error = Inf; %dummy value

% Iterative process for Rs and Rp until Pmax,model = Pmax,experimental

while (error>tol)    

%  Temperature and irradiation effect on the current
dT = T-Tn;
Ipvn = (Rs+Rp)/Rp * Iscn;         % Nominal light-generated current
Ipv = (Ipvn + Ki*dT) *G/Gn;       % Actual light-generated current 
Isc = (Iscn + Ki*dT) *G/Gn;       % Actual short-circuit current

% Increments Rs 
Rs = Rs + .01;  

% Parallel resistance
Rp = Vmp*(Vmp+Imp*Rs)/(Vmp*Ipv-Vmp*Io*exp((Vmp+Imp*Rs)/Vt/Ns/a)+Vmp*Io-Pmax_e);

% Solving the I-V equation for several (V,I) pairs 
clear V
clear I

V = 0:.1:35;               % Voltage vector
I = zeros(1,size(V,2));    % Current vector

for j = 1 : size(V,2) %Calculates for all voltage values 
    
% Solves g = I - f(I,V) = 0 with Newntonn-Raphson
  
g(j) = Ipv-Io*(exp((V(j)+I(j)*Rs)/Vt/Ns/a)-1)-(V(j)+I(j)*Rs)/Rp-I(j);
  
while (abs(g(j)) > 0.001)
      
g(j) = Ipv-Io*(exp((V(j)+I(j)*Rs)/Vt/Ns/a)-1)-(V(j)+I(j)*Rs)/Rp-I(j);
glin(j) = -Io*Rs/Vt/Ns/a*exp((V(j)+I(j)*Rs)/Vt/Ns/a)-Rs/Rp-1;
I_(j) = I(j) - g(j)/glin(j);
I(j) = I_(j);   
  
end  

end % for j = 1 : size(V,2)

plott = 1; %Enables plotting during the algorithm execution

if (plott) 
    
  %Plots the I-V and P-V curves

  %Current x Voltage
  figure(1) 
  grid on
  hold on 
  title('I-V curve - Adjusting Rs and Rp');
  xlabel('V [V]');
  ylabel('I [A]');
  xlim([0 Vocn+1]);
  ylim([0 Iscn+1]);
 
  %Plots I x V curve
  plot(V,I,'LineWidth',2,'Color','k') 
 
  %Plots the "remarkable points" on the I x V curve
  plot([0 Vmp Vocn],[Iscn Imp 0],'o','LineWidth',2,'MarkerSize',5,'Color','k') 

  %Power x Voltage
  figure(2)  
  grid on
  hold on  
  title('P-V curve - Adjusting peak power');
  xlabel('V [V]');
  ylabel('P [W]');
  xlim([0 Vocn+1])
  ylim([0 Vmp*Imp+1]);
    
end % if(plott)

  % Calculates power using the I-V equation
  P = (Ipv-Io*(exp((V+I.*Rs)/Vt/Ns/a)-1)-(V+I.*Rs)/Rp).*V;
  
  Pmax_m = max(P);
  
  error = (Pmax_m-Pmax_e);
  
if (plott) 
    
  %Plots P x V curve
  plot(V,P,'LineWidth',2,'Color','k')
  
  %Plots the "remarkable points" on the power curve
  plot([0 Vmp Vocn],[0 Vmp*Imp 0],'o','LineWidth',2,'MarkerSize',5,'Color','k')
  
end % if (plott)
     
end % while (error>tol) 

  
%% Outputs
 
 % I-V curve
 figure(3) 
 grid on
 hold on 
 title('Adjusted I-V curve');
 xlabel('V [V]');
 ylabel('I [A]');
 xlim([0 Vocn+1]);
 ylim([0 Iscn+1]);
 
 plot(V,I,'LineWidth',2,'Color','k') %
 
 plot([0 Vmp Vocn ],[Iscn Imp 0 ],'o','LineWidth',2,'MarkerSize',5,'Color','k') 
 
 % P-V curve

 figure(4) 
 grid on
 hold on 
 title('Adjusted P-V curve');
 xlabel('V [V]');
 ylabel('P [W]');
 xlim([0 Vocn+1]);
 ylim([0 Vmp*Imp+1]);
  
 plot(V,P,'LineWidth',2,'Color','k') %
 
 plot([0 Vmp Vocn ],[0 Pmax_e 0 ],'o','LineWidth',2,'MarkerSize',5,'Color','k') 
   

disp(sprintf('Model info:\n'));
disp(sprintf(' Rp_min = %f',Rp_min));
disp(sprintf('     Rp = %f',Rp));
disp(sprintf(' Rs_max = %f',Rs_max));
disp(sprintf('     Rs = %f',Rs));
disp(sprintf('      a = %f',a));
disp(sprintf('      T = %f',T-273.15));
disp(sprintf('      G = %f',G));
disp(sprintf(' Pmax,m = %f  (model)',Pmax_m));
disp(sprintf(' Pmax,e = %f  (experimental)',Pmax_e));
disp(sprintf('    tol = %f',tol));
disp(sprintf('P_error = %f',error));
disp(sprintf('    Ipv = %f',Ipv));
disp(sprintf('    Isc = %f',Isc));
disp(sprintf('    Ion = %f',Ion));
disp(sprintf('\n\n'));


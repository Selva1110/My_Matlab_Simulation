function [d] = load1 
d=412.35; end % Set total load here